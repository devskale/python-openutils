# Credgoo

[![Python Version](https://img.shields.io/badge/python-3.6+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](../LICENSE)

**The Secure Credentials Manager for Everywhere.**

Credgoo is a powerful credentials manager that allows you to securely add and maintain API keys in Google Sheets using an encrypted Apps Script integration, making them available everywhere you work.

## Overview

Credgoo transforms your Google Sheets into a secure, centralized vault for your API keys and secrets. By leveraging an encrypted Google Apps Script integration, you can easily manage credentials in a familiar interface and access them securely across all your environments.

Whether you are developing locally, deploying to a staging server, or running in production, Credgoo ensures your credentials are always available, encrypted, and up-to-date. With built-in local caching, you get the convenience of cloud management with the speed and reliability of local access.

## Features

- **Use Everywhere**: Access your credentials seamlessly across local, dev, and production environments.
- **Secure Google Sheets Integration**: Manage keys in Google Sheets with a secure, encrypted Apps Script backend.
- **End-to-End Encryption**: Credentials are encrypted during transmission and storage.
- **Smart Local Caching**: High-performance caching with restrictive permissions (0600) to minimize API calls.
- **Centralized Control**: Update secrets in one place and have them propagate everywhere.
- **Developer Friendly**: Simple CLI and Python API for instant integration.

## Installation

```bash
# Install
uv venv
uv pip install -r https://skale.dev/credgoo
```

## Usage

### Command Line Interface

```bash
credgoo SERVICE_NAME --token BEARER_TOKEN --key ENCRYPTION_KEY
```

Optional arguments:

- `--url`: Custom Google Apps Script URL (defaults to built-in URL)
- `--cache-dir`: Custom cache directory (defaults to ~/.config/api_keys)
- `--no-cache`: Bypass cache and force retrieval from Google Sheets
- `--update`: Update cached key: checks if another key is online, updates it, and provides verbose output if the online key has changed.
- `--save {all,token,key,url,none}`: Specify which credentials to persist (default: `all`). Use `token`, `key`, or `url` to save specific parts, or `none` to disable saving.

### Python API

```python
from credgoo import get_api_key

# Basic usage
# uses cached keys if available
api_key = get_api_key("service_name")

# With custom cache directory
api_key = get_api_key("service_name",
                      bearer_token="your_token",
                      encryption_key="your_key",
                      cache_dir="/path/to/cache")

# Force fresh retrieval (bypass cache)
api_key = get_api_key("service_name",
                      bearer_token="your_token",
                      encryption_key="your_key",
                      no_cache=True)
```

### Credential Storage

Credentials can be stored securely for future use:

```python
from credgoo import store_credentials
from pathlib import Path

store_credentials("your_token", "your_key", "optional_url", Path("~/.config/api_keys/credgoo.txt"))
```

### Caching Behavior

By default, retrieved keys are cached in `~/.config/api_keys/api_keys.json` with restrictive permissions (0600). The cache:

- Is automatically used for subsequent requests
- Can be bypassed with `--no-cache` flag
- Stores keys with restrictive permissions (0600)
- Includes timestamp of when each key was retrieved

## Security Notes

- Always protect your encryption key and bearer token
- Recommended to store credentials in secure locations
- Cache files have restrictive permissions (0600)
- Consider rotating credentials periodically

## Why Credgoo is Great

Credgoo provides a secure and convenient way to manage your API keys:

**Personal Secure Storage**

- Your keys are stored in your personal Google Sheet, not on some third-party server
- Only you have access to your spreadsheet (Google account protected)

**Double-Layer Security**

- Protected by both a SECRET_TOKEN (authentication)
- And an ENCRYPTION_KEY (data security)
- Both are required to access your credentials

**Encrypted Transmission**

- Keys are encrypted before being sent over the network
- Uses robust encryption with unique initialization vectors

**CLI Integration**

- Easy to use from command line with automatic decryption
- No keys stored in plaintext in your local environment

**Centralized Management**

- Update keys in one place (your spreadsheet)
- Changes are immediately available everywhere
- No need to update multiple config files

## Google Apps Script Setup

See [appscript/README.md](appscript/README.md) for instructions on setting up the Google Apps Script integration.

## License

MIT - see [LICENSE](../LICENSE) for details.
